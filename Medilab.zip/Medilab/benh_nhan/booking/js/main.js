$(function() {

  rome(input, { time: false });

});